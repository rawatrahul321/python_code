{
    "name": "Web Refresher",
    "version": "14.0.1.0.0",
    "author": "Compassion Switzerland, Odoo Community Association (OCA)",
    "license": "AGPL-3",
    "website": "https://github.com/OCA/web",
    "qweb": ["templates/pager_button.xml"],
    "depends": ["web"],
    "installable": True,
    "auto_install": False,
}
