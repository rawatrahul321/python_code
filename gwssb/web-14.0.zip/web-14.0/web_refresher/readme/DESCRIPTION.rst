Adds a button next to the pager (in trees/kanban views) to refresh the displayed list.

.. image:: ./static/description/refresh.png
