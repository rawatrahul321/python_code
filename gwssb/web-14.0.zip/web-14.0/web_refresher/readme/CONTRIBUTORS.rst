* Samuel Fringeli
* `Tecnativa <https://www.tecnativa.com>`__:

  * João Marques
