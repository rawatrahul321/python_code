* Dennis Sluijk <d.sluijk@onestein.nl>
* Aldo Soares <soares_aldo@hotmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
