Enables selecting a range of records using the shift key.
