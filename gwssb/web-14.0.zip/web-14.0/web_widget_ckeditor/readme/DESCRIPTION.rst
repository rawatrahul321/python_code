This module adds a new widget `ckeditor` to edit HTML fields using CKEditor.
