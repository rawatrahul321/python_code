* Allow to configure toolbar using widget's options.

.. code-block:: xml

    <field
        name="description_html"
        widget="ckeditor"
        options="{'bulletedList': false, 'pageBreak': true}"
    />


* There seems to be a small incompatibility issue with `web_drop_target`.
  `More information here <https://github.com/OCA/web/pull/2083#issuecomment-970719103>`_
