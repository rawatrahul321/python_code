* `Therp <https://www.therp.nl>`_

    * Holger Brunn <hbrunn@therp.nl>
    * Stefan Rijnhart <stefan@therp.nl>
    * George Daramouskas <gdaramouskas@therp.nl>

* `Camptocamp <https://www.camptocamp.com>`_

    * Iván Todorovich <ivan.todorovich@camptocamp.com>
