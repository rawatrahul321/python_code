* Implement a more efficient way of refreshing timeline after a record update;
* Make `attrs` attribute work;
* Make action attributes work (create, edit, delete) like in form and tree views.
