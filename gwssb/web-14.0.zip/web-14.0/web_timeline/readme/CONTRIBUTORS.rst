* Laurent Mignon <laurent.mignon@acsone.eu>
* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Leonardo Donelli <donelli@webmonks.it>
* Adrien Didenot <adrien.didenot@horanet.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Thong Nguyen Van <thongnv@trobz.com>
* Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Murtaza Mithaiwala <mmithaiwala@opensourceintegrators.com>
* Ammar Officewala <aofficewala@opensourceintegrators.com>
