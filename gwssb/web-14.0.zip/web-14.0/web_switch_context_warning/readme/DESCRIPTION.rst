In Odoo 14 possible to work in different tabs with different companies, now the module only shows a warning when the user or database has been switched.
