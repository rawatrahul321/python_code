This module is meant as a base drag&drop module supporting other actions after some file is dropped so that other modules can add more features.
