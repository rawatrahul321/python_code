To use this module, you need to:

#. drag a file from your local computer onto an Odoo form view
#. it should become an attachment of the currently opened record

.. image:: /web_drop_target/static/description/screenshot.png
    :alt: Screenshot
