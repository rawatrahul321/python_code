**Libraries**

* `base64js <https://raw.githubusercontent.com/beatgammit/base64-js>`_.
