Allows using numpad dot to enter period decimal separator even in localizations
where comma is used instead of period.
