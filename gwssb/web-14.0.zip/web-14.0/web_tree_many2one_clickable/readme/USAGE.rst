Put the mouse pointer over a many2one cell and click the button.

.. image:: ../static/img/clickable.gif
