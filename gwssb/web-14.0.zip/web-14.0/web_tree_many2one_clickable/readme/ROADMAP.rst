This widget is currently not working on the product field in the lines tree of the sale order form, see https://github.com/OCA/web/pull/1438 for further details.
