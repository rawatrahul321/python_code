You need to install the python bokeh library::

    pip3 install bokeh==2.3.1
