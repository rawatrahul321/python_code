When using Odoo, even if a user has no rights to edit a record, the Edit button
is shown. The user can edit the record but won't be able to save his changes.
Now, the user won't be able to click on the Edit button.
