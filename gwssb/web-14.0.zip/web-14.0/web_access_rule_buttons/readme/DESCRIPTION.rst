This addon disables the Edit button on the form views if the user
cannot edit the current record according to the record access rules.
