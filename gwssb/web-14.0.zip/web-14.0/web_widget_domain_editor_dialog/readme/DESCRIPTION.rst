Since v11 introduced the new domain editor widget it's not possible to edit
the selected records from the current domain.

This module reintroduces that dialog to complement the current widget with the
powerful search engine of Odoo.
