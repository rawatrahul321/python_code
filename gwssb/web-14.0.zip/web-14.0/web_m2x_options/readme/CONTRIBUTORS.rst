* David Coninckx <davconinckx@gmail.com>
* Emanuel Cino <ecino@compassion.ch>
* Holger Brunn <hbrunn@therp.nl>
* Nicolas JEUDY <nicolas@sudokeys.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Zakaria Makrelouf <z.makrelouf@gmail.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis <jairo.llopis@tecnativa.com>
  * David Vidal <david.vidal@tecnativa.com>
  * Ernesto Tejeda <ernesto.tejeda87@gmail.com>
  * Carlos Roca
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* Dhara Solanki <dhara.solanki@initos.com> (http://www.initos.com)
