To use this module, you need only to install it. After installation, a red
ribbon will be visible on top left corner of every Odoo backend page
