This module was written to extend the functionality of the web client
to get full width in the form view sheet.

This module works in community edition and in enterprise edition.

This module feature and many other features and improvements to the web backend
are included in `web_responsive module <https://github.com/OCA/web/tree/13.0/web_responsive>`_.
Before installing this module, please consider Web Responsive as a better alternative.
