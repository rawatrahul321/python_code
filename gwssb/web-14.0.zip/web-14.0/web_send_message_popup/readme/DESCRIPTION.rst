In the email/notes threads below the form views, the link 'Send a
message' unfold a text field. From there, a button allows to open the
text field in a full featured email popup with the subject, templates,
attachments and followers.

This module changes the link 'Send a message' so it opens directly the
full featured popup instead of the text field, avoiding an extra click
if the popup is always wanted.
