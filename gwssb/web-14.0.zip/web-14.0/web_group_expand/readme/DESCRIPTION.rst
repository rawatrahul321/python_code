When grouping a list by a field, this module adds two buttons to expand or
collapse all the groups at once.

The buttons appear in the top right, in place of the pagination.

One level of groups is expanded or collapsed at a time.
