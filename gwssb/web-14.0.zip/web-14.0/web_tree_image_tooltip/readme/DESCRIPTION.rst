This module defines a images and icons in tree view via Tooltip.
Additionally, Default width with 30px.
