Mouse Hover in tree view image that time Tooltip effect.
