Insert `widget='image'` in your field view definition in any image field
