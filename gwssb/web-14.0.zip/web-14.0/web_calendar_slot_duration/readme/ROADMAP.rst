* Drop module if/when https://github.com/odoo/odoo/pull/66739 is merged.
