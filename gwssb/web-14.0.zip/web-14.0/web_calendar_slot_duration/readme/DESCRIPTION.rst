This module extends the functionality of backend calendars to support custom
slot durations and to allow you to provide more specific UX regarding event
duration and snapping.
