To use this module, you need to install some other addon that uses it, as it
doesn't provide any end-user functionality.
