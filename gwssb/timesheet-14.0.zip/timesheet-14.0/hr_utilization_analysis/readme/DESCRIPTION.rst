This module allows to view Utilization Analysis from Task Logs.

Features:
 * Configure source data set
 * Select time interval
