This module allows to configure project as having task on timesheet as a
mandatory field.
