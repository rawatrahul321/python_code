To make task selection mandatory on project's timesheets:

# Go to *Project > Projects* and edit the project
# Enable timesheets by checking *Timesheets*
# Make task selection mandatory by checking *Require Tasks on Timesheets*

Default setting can be changed at company level:

# Go to *Project > Configuration > Settings*
# Make task selection mandatory for new projects by checking *Require Tasks on Timesheets*
