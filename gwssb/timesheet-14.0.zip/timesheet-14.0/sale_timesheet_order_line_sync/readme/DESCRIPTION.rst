This module synchronises task sale order line in *not invoiced* timesheet
lines.

Synchronization occurs only when saving a different order line in the task.
