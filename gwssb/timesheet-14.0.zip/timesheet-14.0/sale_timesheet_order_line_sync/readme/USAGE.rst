#. Go to **Project > All Tasks**
#. Open specific task for editing
#. In *Extra Info*, select a customer.
#. Set a Sales Order Item where the invoiced product's *Service Invoicing Policy* is *Timesheets on tasks*
#. Add *Timesheets* to the task if there aren't any.
#. Open Sale Order to view delivered quantity
