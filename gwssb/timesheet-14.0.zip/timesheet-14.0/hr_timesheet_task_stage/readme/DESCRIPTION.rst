This module allows to open and close tasks from account analytic lines.
The selected closed stage is the first one that is found with the mark
"Closed" checked.
