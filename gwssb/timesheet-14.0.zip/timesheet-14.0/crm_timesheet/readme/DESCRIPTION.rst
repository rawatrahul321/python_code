This module allows to generate timesheets from leads/opportunities.
