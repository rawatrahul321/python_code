* improve test coverage
