* Miquel Raïch <miquel.raich@forgeflow.com>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Lois Rilo <lois.rilo@forgeflow.com>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>

* Dennis Sluijk <d.sluijk@onestein.nl>
* Sunanda Chhatbar <sunanda.chhatbar@initos.com>
