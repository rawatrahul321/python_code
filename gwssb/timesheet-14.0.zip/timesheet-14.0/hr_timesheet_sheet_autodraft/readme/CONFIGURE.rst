To enable auto-drafting:

# Go to *Timesheets > Configuration > Settings*
# Enable **Auto-draft Timesheet Sheets** under **Timesheet Options**
