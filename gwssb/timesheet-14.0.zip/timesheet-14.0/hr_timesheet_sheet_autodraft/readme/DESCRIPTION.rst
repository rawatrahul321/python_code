This module adds option to auto-draft Timesheet Sheets whenever a Timesheet
entry is created or modified to ensure it's covered by a relevant Timesheet
Sheet.
