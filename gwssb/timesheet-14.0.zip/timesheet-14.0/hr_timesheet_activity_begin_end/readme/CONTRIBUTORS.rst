* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Luis M. Ontalba
  * Ernesto Tejeda

* `Onestein <https://www.onestein.eu>`_:

  * Andrea Stirpe
* Sunanda Chhatbar <sunanda.chhatbar@initos.com>
