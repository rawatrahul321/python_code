Adds starting and ending hours fields on the timesheet activities.
