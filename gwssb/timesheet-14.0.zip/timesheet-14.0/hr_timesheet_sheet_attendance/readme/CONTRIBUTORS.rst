* Ruchir Shukla <ruchir@bizzappdev.com>
* Shruti Singh <shruti.singh@bizzappdev.com>
* Chirag Parmar <chirag.parmar@bizzappdev.com>
* Naglis Jonaitis <naglis@versada.eu>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Ernesto Tejeda
