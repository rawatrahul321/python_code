This module extends the functionality of hr_timesheet_sheet
and help employees to manage their attendance according to timesheet period.
It provide functionality to checkin/checkout directly from timesheet-sheet.
It also help you/management in performace evaluation by displaing
total attendance time and difference of total attendance time and total working time.
