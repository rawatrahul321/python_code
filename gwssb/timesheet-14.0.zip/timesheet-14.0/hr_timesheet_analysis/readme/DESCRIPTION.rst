This module allows analyzing tracked time in Pivot, Graph views.
