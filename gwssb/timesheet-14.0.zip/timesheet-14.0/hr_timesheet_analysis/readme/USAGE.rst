To use this module, go to :

* Timesheet > Timesheet > My Timesheets
* or Timesheet > Timesheet > All Timesheets

And then click the "graph" icon in the top right menu (next to list, kanban and pivot icons).
