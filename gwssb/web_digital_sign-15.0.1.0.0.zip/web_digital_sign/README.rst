=================
Web Digital Sign
=================

* This module provides the functionality to store digital signature for a record.

* This module is helpfull to make your business process a little bit more faster & makes it more user friendly by providing you digital signature functionality on your documents

* It is touch screen enable so user can add signature with touch devices.

* Digital signature can be very usefull for documents such as sale orders, purchase orders, inovoices, payslips, procurement receipts, etc.


Usage
=====

* To use this module, you need to add widget="signature" to your binary field in your view.

* User can store their digital signature in the binary field, as you can see image.

* As shown in the image, user can add a signature using mouse, pen, or finger.

* User can clear signature using clear button and it will re-initialize the signature.

Bug Tracker
===========

Credits
=======

Contributors
------------


* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>

